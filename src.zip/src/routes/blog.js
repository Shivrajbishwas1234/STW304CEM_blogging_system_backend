const router = require('express').Router();

const {upload, uploader}= require('../fileupload/multer');

const Blog = require('../models/blog');
const Comment = require('../models/comment');
const authenticate = require('../jwt/authenticate');
const { validationResult, body } = require('express-validator');


router.post('/api/blog/create', authenticate,  upload.single('image'), [
    body('title').exists({checkFalsy:true}),
    body('post').exists({checkFalsy:true}),
    body('categories').exists({checkFalsy:true}),
], function(request, response) {
    if(!request.user) {
        return response.status(422).json({
            message: 'You are not authorized.'
        });
    }

    try {
        validationResult(request).throw()
    } catch (error) {
        return response.status(422).json(error.mapped())
    }

    const image= uploader(request.file);

    Blog.create({
        title: request.body.title,
        post: request.body.post,
        categories: request.body.categories,
        userid: request.user.id,
        allow_comment: request.body.allow_comment,
        image: image,
        private: request.body.private,
        created_date: new Date(),
        updated_date: new Date(),
    }, function(err, blog) {
        if(err) {
            return response.status(500).json({message:err.message})
        }
        response.json(blog);
    });
});

router.post('/api/blog', function(request, response) {
    const search = {};
    if(request.body.category) {
        search["categories"] = [request.body.category];
    }
    Blog.find(search).limit(parseInt(request.query.limit)).exec(function(err, blogs) {
        if(err) {
            return response.json({message:err.message});
        }
        response.json(blogs);
    });
});

router.post('/api/blog/:id', authenticate, function(request, response) {

    const id = request.params.id;
    Blog.findById(id, function(err, blog) {
        if(err) {
            return response.status(422).json({
                message: '404 Blog not found'
            });
        }
	blog = blog.toObject();
	
	blog.sameuser = request.user && request.user.id == blog.userid;
	
        response.json(blog);
    });

});

router.post('/api/comment/create/:id', authenticate, upload.none(), function(request, response) {
    if(!request.body.comment) {
        return response.status(422).json({comment: 'comment is required'});
    }
    if(!request.user) {
        return response.status(422).json({
            message: 'You are not authorized.'
        });
    }
    Comment.create({
        comment: request.body.comment,
        userid: request.user.id,
        blogid: request.params.id,
        created_date: new Date(),
        updated_date: new Date()
    }, function(err, comment) {
        if(err) {
            return response.status(422).json({
                message: err.message
            });
        }
        response.json(comment);
    });
});


router.post('/api/blog/:id/update', upload.single('image'), function(request, response){
    const image= uploader(request.file);
    const updateData = {};
    if(image) {
		updateData.image = image;
    }
	if(request.body.title) {
		updateData.title = request.body.title;
	}
	if(request.body.post) {
		updateData.post = request.body.post;
	}
	if(request.body.categories) {
		updateData.categories = request.body.categories;
	}
	
	updateData.private = request.body.private;
	updateData.allow_comment = request.body.allow_comment;
	
	
    Blog.updateOne({
        _id: request.params.id
    }, updateData,
       function(err, blog){
        if(err){
            return response.status(422).json({
                message: err.message
            });
        }
        response.json(blog)
       })
})


 router.post('/api/blog/:id/delete', authenticate, function(request,response){
     if(!request.user) {
         return response.status(422).json({
             message: 'Unauthorized'
         });
     }
     Blog.findById(request.params.id, function(err, blog){
         if(err){
             return response.status(422).json({
                 message: err.message
             })
         }
         if(!blog) {
            return response.status(404).json({
                message: 'Blog not found'
            })
         }
		 blog.delete();
         response.json(blog);
     }).catch(err => response.status(422).json({message:err.message}))
 })

module.exports = router;