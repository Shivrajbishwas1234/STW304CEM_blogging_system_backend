const router = require('express').Router();
const multer = require('multer');
const upload = multer();

const Category = require('../models/category');

router.post('/api/categoy/create', upload.none(), function(request, response) {
    Category.findOne({
        category: request.body.category
    }, function(err, cate) {
        if(err) {
            return response.status(422).json({
                message: err.message
            });
        }
        if(cate) {
            return response.status(422).json({
                message: 'Category already exists.'
            });
        }
        Category.create({
            category: request.body.category
        }, function(err, cate) {
            if(err) {
                return response.status(500).json({
                    message: err.message
                });
            }
            response.json(cate)
        });
    });
});

router.post('/api/categoy/all', function(request, response) {
    Category.find({}, function(err, items) {
        if(err) {
            return response.status(500).json({
                message: err.message
            });
        }
        response.json(items);
    });
});

module.exports = router;