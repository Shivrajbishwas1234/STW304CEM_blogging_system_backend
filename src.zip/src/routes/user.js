const router = require('express').Router();
const {upload, uploader} = require('../fileupload/multer');
const bcrypt = require('bcrypt');
const jwt = require('json-web-token');

const User = require('../models/user');
const authenticate = require('../jwt/authenticate');


router.post('/api/user/register', upload.single('image'), async function(request, response) {
    if(request.body.password !== request.body.confirm_password) {
        return response.status(422).json({
            password: 'Password did not match.'
        });
    }
    if(!request.body.password || !request.body.password.length > 6) {
        return response.status(422).json({
            password: 'Password too short.'
        });
    }

    const password = bcrypt.hashSync(request.body.password, 10);

    const exists = await User.findOne({email: request.body.email});
    if(exists) {
        return response.status(422).json({
            password: 'Email already exists.'
        });
    }

    const image = uploader(request.file);

    User.create({
        firstname: request.body.firstname,
        lastname: request.body.lastname,
        dob: request.body.dob,
        gender: request.body.gender,
        email: request.body.email,
        image: image,
        password: password,
        created_date: new Date(),
        updated_date: new Date(),
    }, function(err, user) {
        if(err) {
            return response.status(500).json({message:err.message})
        }

        response.json(user)
    });
});

router.post('/api/user/login', upload.none(), function(request, response) {
    User.findOne({email: request.body.email}, function(err, user) {
        if(err) {
            return response.status(422).json({message:err.message});
        }
        if(!user) {
            return response.status(422).json({message:'Invalid email'});
        }
        const match = bcrypt.compareSync(request.body.password, user.password);
        if(match) {
            jwt.encode('thestrongestpassword',{id: user.id, email: user.email}, function(err, token) {
                if(err) {
                    return response.status(500).json({
                        message: err.message
                    });
                }
                response.json({
                    token,
                    status: 'success'
                });
            });
        } else {
            response.status(422).json({
                password: 'Invalid email or password.'
            });
        }
    });
});

router.post('/api/user/update', upload.single('image'), authenticate, function(request, response){
	
	const image = uploader(request.file);
	
	const updateData = {
        firstname: request.body.firstname,
        lastname: request.body.lastname,
        dob: request.body.dob,
        gender: request.body.gender,
        updated_date: new Date()
    };
	if(image) {
		updateData.image = image;
	}
    User.updateOne({
        _id: request.user.id
    }, updateData,
    function(err, user){
        if(err){
            return response.status(422).json({
                message: err.message
            });
        }
        response.json(user)
    })

})


router.post('/api/user', authenticate, function(request, response){
    if(!request.user) {
        return response.status(405).json({
            message: 'Unathorized Request'
        });
    }
    User.findById(request.user.id, function(err,user){
        if(err){
            return response.status(422).json({
                message: err.message
            });
        }
        response.json(user)
    })
})

router.post('/api/user/:id/delete', authenticate, function(request,response){
    if(!request.user) {
        return response.status(422).json({
            message: 'Unauthorized'
        });
    }
    User.findById(request.params.id, function(err, user){
        if(err){
            return response.status(422).json({
                message: err.message
            })
        }
        if(!user) {
           return response.status(404).json({
               message: 'User not found'
           })
        }
        user.delete();
        response.json(user);
    })
})

module.exports = router;