const router = require ('express').Router();
const authenticate = require('../jwt/authenticate');
const multer= require('multer');
const comment = require('../models/comment');
const { update } = require('../models/comment');
const upload = multer();


router.post('/api/comment/:id/update',upload.none(), authenticate, function(request, response){
    comment.updateOne({
        _id: request.params.id
    },
    {
        comment: request.body.comment,
        updated_date: new Date(),
    },
    function(err, sts){
        if (err) {
            return response.status(422).json({
                message: err.message
            })
        }
        response.json(sts);
       
    })
})


router.post('/api/comment/:id/delete', authenticate, function(request, response){
    comment.deleteOne({
        _id: request.params.id
    },
    function(err, sts){
        if (err) {
            return response.status(422).json({
                message: err.message
            })
        }
        response.json(sts);
    })
})

router.post('/api/comment/:blog', authenticate, function(request, response) {
    comment.find({
        blogid: request.params.blog
    })
    .populate('userid')
    .exec(function(err, comments) {
        if(err) {
            return response.status(422).json({message:err.message});
        }
        if(request.user) {
            comments = comments.map(x => {
                x = x.toObject();
                x.sameuser = x.userid._id == request.user.id;
                return x;
            });
        }

        response.json(comments);
    });
});

module.exports= router;