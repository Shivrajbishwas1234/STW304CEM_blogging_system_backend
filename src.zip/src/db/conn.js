const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/BlogRegistration", {
    useNewUrlParser:true,
    useUnifiedTopology:true,
    useCreateIndex:true
}).then(()=>{
    console.log('connected successfully');
}).catch(()=>{
    console.log('not connected');
})