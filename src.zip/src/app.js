const express = require("express");
const path = require ("path");
const app = express();
const cors= require('cors');
const bodyParser =require('body-parser');
const hbs = require("hbs");
require("./db/conn");
const port = process.env.PORT || 3000;



const static_path = path.join(__dirname,"../public");

app.use(cors({

}));
app.use(bodyParser.urlencoded({
    extended:true
}));

app.use(express.static(static_path));

app.use(require('./routes/blog'));
app.use(require('./routes/user'));
app.use(require('./routes/category'));
app.use(require('./routes/comment'));



  



app.listen(port, ()=>{
    console.log ('Server is running at port no 3000');
})