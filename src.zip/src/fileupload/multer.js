const multer = require('multer');
const fs = require('fs');

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads')
    },
    filename: function (req, file, cb) {
        const ext = file.mimetype.split('/')[1];
        cb(null, file.fieldname + '-' + (new Date()).getTime() + '.' + ext)
    }
})

var upload = multer({ storage: storage });

function uploader(file) {
    if(!file) return null;
    const tmp_path = file.path;
    var target_path = 'public/' + file.filename;

    /** A better way to copy the uploaded file. **/
    var src = fs.createReadStream(tmp_path);
    var dest = fs.createWriteStream(target_path);
    src.pipe(dest);
    src.on('end', function() {
        console.log('complete');
        fs.unlinkSync(tmp_path);
    });
    return target_path;
}

module.exports = {upload, uploader};