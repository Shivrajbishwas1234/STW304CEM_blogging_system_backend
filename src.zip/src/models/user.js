const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    firstname:String,
    lastname: String,
    dob: Date,
    gender: String,
    email: String,
    password: String,
    image: String,
    Created_date:{
        type: Date,
        defaultValue: new Date()
    }
})
module.exports = mongoose.model('User',userSchema);