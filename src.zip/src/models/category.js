const mongoose = require ('mongoose');

const CategoryShcema = mongoose.Schema({
    category: String,
    created_Date:{
        type: Date,
        defaultValue: new Date()
    },
    updated_date:{
        type: Date,
        defaultValue: new Date()
    }
})
module.exports = mongoose.model('Category',CategoryShcema);