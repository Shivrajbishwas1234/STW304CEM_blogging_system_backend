const mongoose = require('mongoose');

const CommentSchema = mongoose.Schema({
    comment: String,
    userid: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    blogid: String,
    created_date: {
        type: Date,
        defaultValue: new Date()
    },
    updated_date: {
        type: Date,
        defaultValue: new Date()
    }
})
module.exports = mongoose.model('Comment', CommentSchema);
