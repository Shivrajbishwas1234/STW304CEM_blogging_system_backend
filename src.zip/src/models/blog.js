const mongoose = require('mongoose');

const BlogSchema = mongoose.Schema({
    title: String,
    post: String,
    categories: Array,
    userid: String,
    image: String,
    allow_comment: Boolean,
    private: {
        type: Boolean,
        defaultValue: false
    },
    created_date: Date,
    updated_date: Date,
});

module.exports = mongoose.model('Blog', BlogSchema);