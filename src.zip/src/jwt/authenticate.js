const jwt = require('json-web-token');
const User = require('../models/user');

module.exports = function(request, response, next) {
    const authorization = request.headers.authorization;
    if(authorization) {
        const token = authorization.split(' ')[1];
        jwt.decode('thestrongestpassword', token, function(err, payload) {
            if(err) {
                return next();
            }
            User.findById(payload.id, function(err, user) {
                if(!err) {
                    request.user = user;
                }
                next();
            });
        });
    } else {
        next();
    }
};