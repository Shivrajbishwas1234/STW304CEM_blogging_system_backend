# Installation
> `npm install --save @types/istanbul-reports`

# Summary
This package contains type definitions for istanbul-reports (https://github.com/istanbuljs/istanbuljs).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/istanbul-reports.

### Additional Details
 * Last updated: Fri, 15 May 2020 04:09:43 GMT
 * Dependencies: [@types/istanbul-lib-report](https://npmjs.com/package/@types/istanbul-lib-report), [@types/istanbul-lib-coverage](https://npmjs.com/package/@types/istanbul-lib-coverage)
 * Global values: none

# Credits
These definitions were written by [Jason Cheatham](https://github.com/jason0x43).
