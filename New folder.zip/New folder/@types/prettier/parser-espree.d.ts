import { Parser } from '.';

declare const parser: { parsers: { [parserName: string]: Parser } };
export = parser;
